// src/types/navigation.ts

import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RouteProp } from '@react-navigation/native';

// Define your Root Stack Param List
export type RootStackParamList = {
    Login: undefined;    // No parameters expected for Login screen
    Register: undefined; // No parameters expected for Register screen
    Home: undefined;
    SubcontractorHome: undefined;     // No parameters expected for Home screen
};

// Define Navigation and Route Props for Login Screen
export type LoginScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Login'>;
export type LoginScreenRouteProp = RouteProp<RootStackParamList, 'Login'>;

// Combine them into a single Props type for the Login component
export type LoginProps = {
    navigation: LoginScreenNavigationProp; // Navigation prop with defined types
    route: LoginScreenRouteProp;           // Route prop with defined types
};

// Define Navigation and Route Props for Register Screen
export type RegisterScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Register'>;
export type RegisterScreenRouteProp = RouteProp<RootStackParamList, 'Register'>;

// Combine them into a single Props type for the Register component
export type RegisterProps = {
    navigation: RegisterScreenNavigationProp; // Navigation prop for Register
    route: RegisterScreenRouteProp;           // Route prop for Register
};

// Define Navigation and Route Props for Home Screen (if needed)
export type HomeScreenNavigationProp = NativeStackNavigationProp<RootStackParamList, 'Home'>;
export type HomeScreenRouteProp = RouteProp<RootStackParamList, 'Home'>;

// Combine them into a single Props type for the Home component
export type HomeProps = {
    navigation: HomeScreenNavigationProp; // Navigation prop for Home
    route: HomeScreenRouteProp;           // Route prop for Home
};
