import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Title, Paragraph } from 'react-native-paper';

interface ServiceDetailsProps {
  route: {
    params: {
      title: string;
      description: string;
    };
  };
}

const ServiceDetails: React.FC<ServiceDetailsProps> = ({ route }) => {
  const { title, description } = route.params;

  return (
    <View style={styles.container}>
      <Title>{title}</Title>
      <Paragraph>{description}</Paragraph>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
});

export default ServiceDetails;
