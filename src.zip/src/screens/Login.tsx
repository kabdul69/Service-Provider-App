import React, { useState } from 'react';
import { View, StyleSheet, Alert } from 'react-native';
import { TextInput, Button } from 'react-native-paper';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const Login: React.FC<{ navigation: any }> = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login } = useAuth();

  const handleLogin = async () => {
    try {
      console.log('Attempting login...');
      const response = await axios.post('http://10.0.2.2:5000/api/auth/login', {
        email,
        password,
      });
      console.log('Login response:', response.data);
      Alert.alert('Success', 'Login successful');
    } catch (error: unknown) {
      if (axios.isAxiosError(error)) {
        // Handle Axios error
        console.log('Login error:', error.response?.data || error.message);
        Alert.alert(
          'Login Failed',
          error.response?.data?.message || 'An error occurred. Please try again.'
        );
      } else {
        // Handle generic error
        console.error('Unexpected error:', error);
        Alert.alert('Error', 'An unexpected error occurred.');
      }
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        label="Email"
        value={email}
        onChangeText={setEmail}
        keyboardType="email-address"
        autoCapitalize="none"
        style={styles.input}
      />
      <TextInput
        label="Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
        style={styles.input}
      />
      <Button mode="contained" onPress={handleLogin} style={styles.button}>
        Login
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', paddingHorizontal: 16 },
  input: { marginBottom: 16 },
  button: { marginTop: 16 },
});

export default Login;
