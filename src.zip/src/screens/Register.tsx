import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { TextInput, Button, Title } from 'react-native-paper';
import { useAuth } from '../context/AuthContext';

interface RegisterUser {
  name: string;
  email: string;
  password: string;
  userType: 'company' | 'subcontractor';
}

const Register: React.FC<{ navigation: any }> = ({ navigation }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [userType, setUserType] = useState<'company' | 'subcontractor'>('company');

  const { register } = useAuth();

  const handleRegister = async () => {
    try {
      await register({ name, email, password, userType } as RegisterUser); // Ensure password is included
      navigation.navigate('Login');
    } catch (error) {
      console.error('Registration failed:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Title>Register</Title>
      <TextInput
        label="Name"
        value={name}
        onChangeText={setName}
        style={styles.input}
      />
      <TextInput
        label="Email"
        value={email}
        onChangeText={setEmail}
        style={styles.input}
      />
      <TextInput
        label="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={styles.input}
      />
      {/* Toggle for user type */}
      <View style={styles.toggleContainer}>
        <Button
          mode={userType === 'company' ? 'contained' : 'outlined'}
          onPress={() => setUserType('company')}
          style={styles.toggleButton}
        >
          Company
        </Button>
        <Button
          mode={userType === 'subcontractor' ? 'contained' : 'outlined'}
          onPress={() => setUserType('subcontractor')}
          style={styles.toggleButton}
        >
          Subcontractor
        </Button>
      </View>
      <Button mode="contained" onPress={handleRegister}>
        Register
      </Button>
      <Button onPress={() => navigation.navigate('Login')}>
        Already have an account? Login
      </Button>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 16,
  },
  input: {
    marginBottom: 12,
  },
  toggleContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  toggleButton: {
    flex: 1,
    marginHorizontal: 4,
  },
});

export default Register;
