import React, { useState, useEffect } from 'react';
import {
  View,
  StyleSheet,
  Dimensions,
  SafeAreaView,
} from 'react-native';
import {
  Title,
  FAB,
  Portal,
  Modal,
} from 'react-native-paper';
import MapView, { Marker } from 'react-native-maps';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth, User } from '../context/AuthContext';
import ServiceForm from '../components/ServiceForm';
import axios from 'axios';

// Define Provider type
interface Provider {
  _id: string;
  name: string;
  location: {
    coordinates: [number, number];
  };
}

const CompanyDashboard = () => {
  const [services, setServices] = useState<any[]>([]);
  const [providers, setProviders] = useState<Provider[]>([]);
  const [isFormVisible, setIsFormVisible] = useState(false);

  const auth = useAuth();
  const user = auth?.user; // Typed User | undefined

  // If user is not authenticated
  if (!user) {
    return (
      <SafeAreaView style={styles.container}>
        <Title style={styles.title}>Please log in to access the dashboard.</Title>
      </SafeAreaView>
    );
  }

  useEffect(() => {
    fetchServices();
    fetchNearbyProviders();
  }, []);

  const fetchServices = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const response = await axios.get('http://10.0.2.2:5000/api/services', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setServices(response.data);
    } catch (error) {
      console.error('Error fetching services:', error);
    }
  };

  const fetchNearbyProviders = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const response = await fetch('http://10.0.2.2:5000/api/providers/nearby', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      const data: Provider[] = await response.json();
      setProviders(data);
    } catch (error) {
      console.error('Error fetching providers:', error);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <Title style={styles.title}>Company Dashboard</Title>

      <View style={styles.mapContainer}>
        <MapView
          style={styles.map}
          initialRegion={{
            latitude: 37.78825,
            longitude: -122.4324,
            latitudeDelta: 0.0922,
            longitudeDelta: 0.0421,
          }}
        >
          {providers.map(provider => (
            <Marker
              key={provider._id}
              coordinate={{
                latitude: provider.location.coordinates[1],
                longitude: provider.location.coordinates[0],
              }}
              title={provider.name}
            />
          ))}
        </MapView>
      </View>

      <Portal>
        <FAB
          style={styles.fab}
          icon="plus"
          onPress={() => setIsFormVisible(true)}
          label="New Service"
        />
      </Portal>

      <Portal>
        <Modal
          visible={isFormVisible}
          onDismiss={() => setIsFormVisible(false)}
          contentContainerStyle={styles.modalContent}
        >
          <ServiceForm
            onSubmit={() => {
              setIsFormVisible(false);
              fetchServices();
            }}
          />
        </Modal>
      </Portal>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    textAlign: 'center',
    marginVertical: 16,
  },
  mapContainer: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: 8,
    margin: 16,
  },
  map: {
    width: Dimensions.get('window').width - 32,
    height: '100%',
  },
  fab: {
    position: 'absolute',
    margin: 16,
    right: 0,
    bottom: 0,
  },
  modalContent: {
    backgroundColor: 'white',
    padding: 20,
    margin: 20,
    borderRadius: 8,
  },
});

export default CompanyDashboard;
