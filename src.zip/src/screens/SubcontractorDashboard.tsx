import React, { useEffect, useState } from 'react';
import { View, StyleSheet, FlatList } from 'react-native';
import { Title, Card, Paragraph } from 'react-native-paper';
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface ServiceRequest {
  id: string;
  title: string;
  description: string;
}

const SubcontractorDashboard: React.FC = () => {
  const [serviceRequests, setServiceRequests] = useState<ServiceRequest[]>([]);

  useEffect(() => {
    const fetchServiceRequests = async () => {
      try {
        const token = await AsyncStorage.getItem('token');
        const response = await axios.get('http://10.0.2.2:5000/api/service-requests', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setServiceRequests(response.data);
      } catch (error) {
        console.error('Error fetching service requests:', error);
      }
    };
  
    fetchServiceRequests();
  }, []);

  return (
    <View style={styles.container}>
      <Title>Available Service Requests</Title>
      <FlatList
        data={serviceRequests}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Card style={styles.card}>
            <Card.Title title={item.title} />
            <Card.Content>
              <Paragraph>{item.description}</Paragraph>
            </Card.Content>
          </Card>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 16,
    backgroundColor: '#fff',
  },
  card: {
    marginBottom: 12,
  },
});

export default SubcontractorDashboard;
