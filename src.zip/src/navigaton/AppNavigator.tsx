import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons';

// Import the navigation types
import { RootStackParamList } from '../types/navigation';

// Screens
import Login from '../screens/Login';
import Register from '../screens/Register';
import CompanyDashboard from '../screens/CompanyDashboard';
import SubcontractorDashboard from '../screens/SubcontractorDashboard';
import ProfileSettings from '../screens/ProfileSettings';

// Create stack and tab navigators with typed param lists
const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator();

// Company Tabs
const CompanyTabs: React.FC = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size }) => {
        let iconName: string;
        if (route.name === 'Dashboard') {
          iconName = focused ? 'home' : 'home-outline';
        } else if (route.name === 'Profile') {
          iconName = focused ? 'person' : 'person-outline';
        } else {
          iconName = 'help';
        }
        return <Ionicons name={iconName} size={size} color={color} />;
      },
    })}
  >
    <Tab.Screen name="Dashboard" component={CompanyDashboard} />
    <Tab.Screen name="Profile" component={ProfileSettings} />
  </Tab.Navigator>
);

// Subcontractor Tabs
const SubcontractorTabs: React.FC = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ focused, color, size }) => {
        let iconName: string;
        if (route.name === 'Dashboard') {
          iconName = focused ? 'briefcase' : 'briefcase-outline';
        } else if (route.name === 'Profile') {
          iconName = focused ? 'person' : 'person-outline';
        } else {
          iconName = 'help';
        }
        return <Ionicons name={iconName} size={size} color={color} />;
      },
    })}
  >
    <Tab.Screen name="Dashboard" component={SubcontractorDashboard} />
    <Tab.Screen name="Profile" component={ProfileSettings} />
  </Tab.Navigator>
);

const AppNavigator: React.FC = () => (
  <NavigationContainer>
    <Stack.Navigator>
      <Stack.Screen name="Login" component={Login} options={{ headerShown: false }} />
      <Stack.Screen name="Register" component={Register} options={{ headerShown: false }} />
      <Stack.Screen name="Home" component={CompanyTabs} options={{ headerShown: false }} />
      <Stack.Screen name="SubcontractorHome" component={SubcontractorTabs} options={{ headerShown: false }} />
    </Stack.Navigator>
  </NavigationContainer>
);

export default AppNavigator;