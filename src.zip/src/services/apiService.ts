// src/services/apiService.ts
import axios from 'axios';

const API_URL = 'http://192.168.1.109:5000/api'; // Replace with your local IP address

// Function to log in a user
export const loginUser = async (email: string, password: string) => {
    try {
        const response = await axios.post(`${API_URL}/auth/login`, { email, password });
        return response.data; // Return the response data
    } catch (error) {
        throw error; // Throw error for handling in the calling component
    }
};

// Function to register a user
export const registerUser = async (name: string, email: string, password: string) => {
    try {
        const response = await axios.post(`${API_URL}/auth/register`, { name, email, password });
        return response.data;
    } catch (error) {
        throw error;
    }
};

// Function to fetch data (e.g., services)
export const fetchServices = async () => {
    try {
        const response = await axios.get(`${API_URL}/services`);
        return response.data;
    } catch (error) {
        throw error;
    }
};

// Function to post a service request
export const postServiceRequest = async (serviceData: any) => {
    try {
        const response = await axios.post(`${API_URL}/services/request`, serviceData);
        return response.data;
    } catch (error) {
        throw error;
    }
};
